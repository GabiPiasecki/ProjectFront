import "./Footer.css";

function Footer(): JSX.Element {
    return (
        <div className="Footer">
        </div>
    );
}

export default Footer;
