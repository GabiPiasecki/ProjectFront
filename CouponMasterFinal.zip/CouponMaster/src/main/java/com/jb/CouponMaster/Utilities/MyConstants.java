package com.jb.CouponMaster.Utilities;

public class MyConstants {
    public static String adminMail = "admin@admin.com";
    public static String adminPassword = "admin";
}