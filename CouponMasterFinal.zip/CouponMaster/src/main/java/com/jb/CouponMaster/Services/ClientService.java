package com.jb.CouponMaster.Services;

import org.springframework.stereotype.Service;

/**
 * A parent service to return in the login method, since we can't know what service it is yet
 */
@Service
public class ClientService {
}