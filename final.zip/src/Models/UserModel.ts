class UserModel{
    email:string;
    password:string;
    userType:string;
    token:string;
}

export default UserModel;