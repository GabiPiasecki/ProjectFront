package com.jb.CouponMaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouponMasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
