class CredentialsModel{
    email:string;
    password:string;
    userType:string;
}
export default CredentialsModel;
