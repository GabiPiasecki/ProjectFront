class Coupon{
    id: number;
    companyID: number;
    title: string;
    description: string;
    category: string;
    startDate: string;
    endDate: string;
    amount: number;
    price: number;
    image: string;
}

export default Coupon;